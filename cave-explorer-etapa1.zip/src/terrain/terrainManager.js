import { Container } from 'pixi.js';
import { CHUNK_PIXELS } from './config.js';
import { createChunk } from './chunk.js';

export class TerrainManager {
  constructor(seed) {
    this.seed = seed;
    this.container = new Container();
    this.chunks = new Map();
  }
  update(centerX, centerY, screenWidth, screenHeight) {
    const margin = 1;
    const left = Math.floor((centerX - screenWidth / 2) / CHUNK_PIXELS) - margin;
    const right = Math.floor((centerX + screenWidth / 2) / CHUNK_PIXELS) + margin;
    const top = Math.floor((centerY - screenHeight / 2) / CHUNK_PIXELS) - margin;
    const bottom = Math.floor((centerY + screenHeight / 2) / CHUNK_PIXELS) + margin;
    const needed = new Set();
    for (let cy = top; cy <= bottom; cy++) for (let cx = left; cx <= right; cx++) {
      const key = `${cx},${cy}`;
      needed.add(key);
      if (!this.chunks.has(key)) {
        const chunk = createChunk(cx, cy, this.seed);
        this.chunks.set(key, chunk);
        this.container.addChild(chunk.sprite);
      }
    }
    // Solo se conserva lo cercano a la cámara. La seed permite regenerarlo igual después.
    for (const [key, chunk] of this.chunks) if (!needed.has(key)) {
      this.container.removeChild(chunk.sprite);
      chunk.sprite.destroy();
      chunk.texture.destroy(true);
      this.chunks.delete(key);
    }
  }
  get count() { return this.chunks.size; }
}
