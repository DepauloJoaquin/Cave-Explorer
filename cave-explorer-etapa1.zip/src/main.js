import { Application, Container, Graphics } from 'pixi.js';
import '../style.css';
import { Camera } from './core/camera.js';
import { TerrainManager } from './terrain/terrainManager.js';

const params = new URLSearchParams(window.location.search);
const seed = Number.parseInt(params.get('seed') ?? '1739', 10) || 1739;
const app = new Application();
await app.init({ resizeTo: window, background: '#080d17', antialias: false, preference: 'webgl', resolution: Math.min(window.devicePixelRatio || 1, 2), autoDensity: true });
document.querySelector('#game').appendChild(app.canvas);
document.querySelector('#seed-label').textContent = seed;

const worldLayer = new Container();
app.stage.addChild(worldLayer);
const terrain = new TerrainManager(seed);
worldLayer.addChild(terrain.container);
const camera = new Camera(0, 0);
camera.attach(document.querySelector('#game'));

// Marcador de referencia para que se identifique el punto de inicio, NO es un jugador.
const startMarker = new Graphics();
startMarker.circle(0, 0, 11).fill({ color: 0x7ee6f9, alpha: .14 });
startMarker.circle(0, 0, 4).fill(0xbff9ff);
startMarker.circle(0, 0, 18).stroke({ color: 0x7ee6f9, alpha: .25, width: 1 });
worldLayer.addChild(startMarker);

const coordsEl = document.querySelector('#coordinates');
const chunksEl = document.querySelector('#chunk-count');
let infoInterval = 0;
let previousWidth = 0, previousHeight = 0;
function updateScene(dt) {
  camera.update(dt);
  const width = app.screen.width, height = app.screen.height;
  if (previousWidth !== width || previousHeight !== height) { previousWidth = width; previousHeight = height; infoInterval = 1; }
  terrain.update(camera.x, camera.y, width, height);
  camera.apply(worldLayer, width, height);
  infoInterval += dt;
  if (infoInterval > .12) {
    coordsEl.textContent = `X ${Math.round(camera.x)} · Y ${Math.round(camera.y)}`;
    chunksEl.textContent = `${terrain.count} chunks`;
    infoInterval = 0;
  }
}
updateScene(0);
app.ticker.add(ticker => updateScene(Math.min(ticker.deltaMS / 1000, .05)));
